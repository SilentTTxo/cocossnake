var res = {
    HelloWorld_png : "res/HelloWorld.png",
    CloseNormal_png : "res/CloseNormal.png",
    CloseSelected_png : "res/CloseSelected.png",
    BackGround_png : "res/title.png",
    PlayB_png : "res/BattleBg.png",
    Start_N_png : "res/MenuStart.png",
    Start_S_png : "res/MenuStartS.png",
    Yellow_png : "res/Yellow.png",
    Red_png : "res/Red.png",
    Blue_png : "res/Blue.png",
    YellowB_png : "res/YellowB.png",
    Head_png : "res/Head.png"
};

var g_resources = [];
for (var i in res) {
    g_resources.push(res[i]);
}